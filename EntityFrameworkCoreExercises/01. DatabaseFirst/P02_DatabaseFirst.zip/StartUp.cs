﻿using P02_DatabaseFirst.Data;

namespace P02_DatabaseFirst
{
    class StartUp
    {
        static void Main()
        {
            var db = new SoftUniDbContext();
        }
    }
}
