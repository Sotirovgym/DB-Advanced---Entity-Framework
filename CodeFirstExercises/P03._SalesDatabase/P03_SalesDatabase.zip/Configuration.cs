﻿namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=SOTIROVGYM-PC\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
