﻿using System;

namespace P01_HospitalDatabase
{
    public class Program
    {
        public static void Main()
        {
            
        }
    }
}
