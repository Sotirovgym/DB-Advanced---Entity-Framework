﻿using System;

namespace P02._HospitalDatabaseModification
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
