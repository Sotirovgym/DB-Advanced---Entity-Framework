﻿namespace P01_HospitalDatabase
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=SOTIROVGYM-PC\SQLEXPRESS;Database=HospitalDatabaseModification;Integrated Security=True";
    }
}
