﻿namespace P01_StudentSystem
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=SOTIROVGYM-PC\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
